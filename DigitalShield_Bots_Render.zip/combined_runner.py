import os
import sys
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PACKAGES_DIR = os.path.join(BASE_DIR, "packages_runtime")
PYZ_DIR = os.path.join(PACKAGES_DIR, "PYZ.pyz_extracted")

if BASE_DIR in sys.path:
    sys.path.remove(BASE_DIR)
sys.path.insert(0, BASE_DIR)

for p in [PACKAGES_DIR, PYZ_DIR]:
    if os.path.exists(p) and p not in sys.path:
        sys.path.append(p)

# ----------------- RENDER / WEB HEALTH CHECK SERVER -----------------
class HealthHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        status_lines = [
            "OK - Digital Shield Telegram Bots are LIVE on Render!",
            "- Dailytrx Post Bot (@Dailytrxmatebot): Running",
            "- Proof Manager Bot (@Mangerprofbot): Running",
            "Server Time: " + time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())
        ]
        status_msg = "\n".join(status_lines) + "\n"
        self.wfile.write(status_msg.encode("utf-8"))

    def log_message(self, format, *args):
        # Silence access logs so keep-alive pings don't clutter terminal logs
        pass

def run_health_server():
    port = int(os.environ.get("PORT", 8080))
    server = HTTPServer(("0.0.0.0", port), HealthHandler)
    print(f">> [Render Web Service] Health-check server listening on 0.0.0.0:{port}")
    server.serve_forever()

def run_trx_bot():
    import friend_trx_bot
    while True:
        try:
            print(">> [Bot 1] Dailytrx Post Bot (@Dailytrxmatebot) is RUNNING!")
            friend_trx_bot.bot.infinity_polling(none_stop=True, timeout=60, long_polling_timeout=30)
        except Exception as e:
            print(f">> [Bot 1] Dailytrx Bot Polling Error: {e}. Reconnecting in 5 seconds...")
            time.sleep(5)

def run_manager_bot():
    import friend_manager_bot
    while True:
        try:
            print(">> [Bot 2] Proof Manager Bot (@Mangerprofbot) is RUNNING!")
            friend_manager_bot.bot.infinity_polling(none_stop=True, timeout=60, long_polling_timeout=30)
        except Exception as e:
            print(f">> [Bot 2] Manager Bot Polling Error: {e}. Reconnecting in 5 seconds...")
            time.sleep(5)

if __name__ == "__main__":
    print("=================================================================")
    print("   DIGITAL SHIELD TELEGRAM BOTS - 24/7 RUNNER (RENDER READY)")
    print("=================================================================")

    # Start HTTP health server in background thread so Render detects port binding
    web_thread = threading.Thread(target=run_health_server, daemon=True)
    web_thread.start()

    print(">> Initializing Bot runners in parallel threads...")

    t1 = threading.Thread(target=run_trx_bot, daemon=True)
    t2 = threading.Thread(target=run_manager_bot, daemon=True)

    t1.start()
    t2.start()

    print("=================================================================")
    print(">> SUCCESS: BOTH BOTS ARE ACTIVE & LIVE 24/7!")
    print(">> Bot 1: https://t.me/Dailytrxmatebot")
    print(">> Bot 2: https://t.me/Mangerprofbot")
    print(">> Web Port Status: LISTENING FOR RENDER / UPTIME PINGS")
    print("=================================================================")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nShutting down bots...")
