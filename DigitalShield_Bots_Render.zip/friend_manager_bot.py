import os
import sys
import json
import time
from datetime import datetime, date

# Ensure local packages are on sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PACKAGES_DIR = os.path.join(BASE_DIR, "packages_runtime")
PYZ_DIR = os.path.join(PACKAGES_DIR, "PYZ.pyz_extracted")
if BASE_DIR in sys.path:
    sys.path.remove(BASE_DIR)
sys.path.insert(0, BASE_DIR)
for p in [PACKAGES_DIR, PYZ_DIR]:
    if os.path.exists(p) and p not in sys.path:
        sys.path.append(p)

import telebot
from telebot import types
from openpyxl import Workbook

DATA_DIR = os.path.join(BASE_DIR, "data_manager")
PROOFS_DIR = os.path.join(DATA_DIR, "proofs")
DATABASE_FILE = os.path.join(DATA_DIR, "account_proofs.json")
EXCEL_FILE = os.path.join(DATA_DIR, "Daily_Proof_Report.xlsx")
TRACKER_FILE = os.path.join(DATA_DIR, "tracked_messages.json")
TOKEN = os.environ.get("MANAGER_BOT_TOKEN", "8859345086:AAGV6_vudMIXu7gvAky1ujKCt9Dsj0qdeLY").strip()

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PROOFS_DIR, exist_ok=True)

bot = telebot.TeleBot(TOKEN)
user_sessions = {}

TOPIC_TITLES = {
    1: "Work To Earn (Referral System)",
    2: "Digital Shield Wallet APP & Features",
    3: "DSpay Payment Services & USDT Gateway"
}

# ----------------- TRACKED MESSAGES (FOR CLEAR CHAT) -----------------
def load_tracker():
    if os.path.exists(TRACKER_FILE):
        try:
            with open(TRACKER_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_tracker(tracker):
    try:
        with open(TRACKER_FILE, "w", encoding="utf-8") as f:
            json.dump(tracker, f, indent=2)
    except Exception:
        pass

def track_message(chat_id, msg_id, acc_num=None):
    tracker = load_tracker()
    cid = str(chat_id)
    if cid not in tracker:
        tracker[cid] = {"all": [], "by_acc": {}}
    if msg_id not in tracker[cid]["all"]:
        tracker[cid]["all"].append(msg_id)
    if acc_num is not None:
        anum = str(acc_num)
        if anum not in tracker[cid]["by_acc"]:
            tracker[cid]["by_acc"][anum] = []
        if msg_id not in tracker[cid]["by_acc"][anum]:
            tracker[cid]["by_acc"][anum].append(msg_id)
    save_tracker(tracker)

def send_tracked_message(chat_id, text, acc_num=None, **kwargs):
    msg = bot.send_message(chat_id, text, **kwargs)
    track_message(chat_id, msg.message_id, acc_num)
    return msg

def send_tracked_photo(chat_id, photo, acc_num=None, **kwargs):
    msg = bot.send_photo(chat_id, photo, **kwargs)
    track_message(chat_id, msg.message_id, acc_num)
    return msg

def send_tracked_document(chat_id, document, acc_num=None, **kwargs):
    msg = bot.send_document(chat_id, document, **kwargs)
    track_message(chat_id, msg.message_id, acc_num)
    return msg

def delete_messages(chat_id, msg_ids):
    count = 0
    for mid in msg_ids:
        try:
            bot.delete_message(chat_id, mid)
            count += 1
            time.sleep(0.02)
        except Exception:
            pass
    return count

# ----------------- DATABASE HELPERS -----------------
def load_db():
    if os.path.exists(DATABASE_FILE):
        try:
            with open(DATABASE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_db(db):
    with open(DATABASE_FILE, "w", encoding="utf-8") as f:
        json.dump(db, f, indent=2, ensure_ascii=False)
    export_to_excel(db)

def export_to_excel(db):
    today = date.today().isoformat()
    try:
        wb = Workbook()
        ws = wb.active
        ws.title = "Proof Report"
        headers = [
            "Date", "Account",
            "Topic 1 Link", "Topic 1 SS Path",
            "Topic 2 Link", "Topic 2 SS Path",
            "Topic 3 Link", "Topic 3 SS Path",
            "Completed"
        ]
        ws.append(headers)
        
        for acc_num in range(1, 101):
            key = str(acc_num)
            data = db.get(key, {})
            t = data.get("topics", {})
            t1 = t.get("1", {})
            t2 = t.get("2", {})
            t3 = t.get("3", {})
            
            row = [
                data.get("date", today),
                f"Account #{acc_num}",
                t1.get("link", ""),
                t1.get("file_path", ""),
                t2.get("link", ""),
                t2.get("file_path", ""),
                t3.get("link", ""),
                t3.get("file_path", ""),
                "Yes" if data.get("completed") else "Incomplete"
            ]
            ws.append(row)
        wb.save(EXCEL_FILE)
    except Exception as e:
        print("Excel export error:", e)

# ----------------- KEYBOARDS -----------------
def get_main_keyboard():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    b1 = types.KeyboardButton("📤 Upload Proof")
    b2 = types.KeyboardButton("📂 View Account Proof")
    b3 = types.KeyboardButton("📊 Full Status")
    b4 = types.KeyboardButton("📥 Download Excel Report")
    b5 = types.KeyboardButton("🧹 Clear Chat")
    markup.add(b1, b2)
    markup.add(b3, b4)
    markup.add(b5)
    return markup

def get_clear_chat_inline_kb():
    markup = types.InlineKeyboardMarkup(row_width=1)
    b1 = types.InlineKeyboardButton("👤 Clear Single Account Proof Chat", callback_data="mgr_clear_acc_prompt")
    b2 = types.InlineKeyboardButton("💥 Clear All Chat History", callback_data="mgr_clear_all_confirm")
    b3 = types.InlineKeyboardButton("❌ Cancel", callback_data="mgr_clear_cancel")
    markup.add(b1, b2, b3)
    return markup

# ----------------- COMMANDS & MENU HANDLERS -----------------
@bot.message_handler(commands=["start", "menu"])
def cmd_start(message):
    db = load_db()
    completed_count = sum(1 for v in db.values() if v.get("completed"))
    welcome = (
        "<b>👋 Welcome to X Account Proof Manager Bot</b>\n\n"
        "Manage live tweet links and screenshots account-wise and topic-wise.\n\n"
        f"• Total Accounts: <b>100</b>\n"
        f"• Completed Proofs: <b>{completed_count} / 100</b>\n"
        "• Structured per Account: Topic 1 (Link+SS), Topic 2 (Link+SS), Topic 3 (Link+SS).\n\n"
        "<b>✨ Features:</b>\n"
        "✅ 1-by-1 Photo + Live Link verification\n"
        "✅ Real-time Excel auto-sync\n"
        "✅ <b>🧹 Clear Chat:</b> Daily work complete hone ke baad chat clean karein!\n\n"
        "Niche diye gaye buttons se shuru karein:"
    )
    send_tracked_message(message.chat.id, welcome, parse_mode="HTML", reply_markup=get_main_keyboard())

@bot.message_handler(func=lambda msg: msg.text == "📤 Upload Proof")
def btn_upload_proof(message):
    user_sessions[message.chat.id] = {"action": "waiting_acc_num_upload"}
    send_tracked_message(
        message.chat.id,
        "<b>📤 UPLOAD ACCOUNT PROOF</b>\n\n"
        "Kis Account ka proof submit karna hai? <b>Account number bhejo (1 to 100):</b>\n"
        "Example: <code>1</code> ya <code>15</code>",
        parse_mode="HTML"
    )

@bot.message_handler(func=lambda msg: msg.text == "📂 View Account Proof")
def btn_view_proof(message):
    user_sessions[message.chat.id] = {"action": "waiting_acc_num_view"}
    send_tracked_message(
        message.chat.id,
        "<b>📂 VIEW ACCOUNT PROOF</b>\n\n"
        "Kis Account ka proof dekhna hai? <b>Account number bhejo (1 to 100):</b>\n"
        "Example: <code>1</code> ya <code>15</code>",
        parse_mode="HTML"
    )

@bot.message_handler(func=lambda msg: msg.text == "📊 Full Status")
def btn_full_status(message):
    db = load_db()
    completed = []
    partial = []
    empty = []
    for acc in range(1, 101):
        key = str(acc)
        if key in db and db[key].get("completed"):
            completed.append(acc)
        elif key in db and db[key].get("topics"):
            partial.append(acc)
        else:
            empty.append(acc)
            
    text = (
        "<b>📊 100 ACCOUNTS PROOF STATUS</b>\n\n"
        f"✅ <b>Fully Completed:</b> {len(completed)} / 100\n"
        f"⏳ <b>Partially Done:</b> {len(partial)} / 100\n"
        f"❌ <b>Pending / Empty:</b> {len(empty)} / 100\n\n"
    )
    if completed:
        text += "<b>Completed Accs:</b> " + ", ".join(map(str, completed[:20]))
        if len(completed) > 20:
            text += f"... (+{len(completed) - 20} more)\n\n"
        else:
            text += "\n\n"
    if partial:
        text += "<b>Partial Accs:</b> " + ", ".join(map(str, partial[:15])) + "\n\n"
        
    text += "Excel sheet download karne ke liye <b>📥 Download Excel Report</b> dabayein."
    send_tracked_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_main_keyboard())

@bot.message_handler(func=lambda msg: msg.text == "📥 Download Excel Report")
def btn_download_excel(message):
    db = load_db()
    export_to_excel(db)
    if os.path.exists(EXCEL_FILE):
        with open(EXCEL_FILE, "rb") as f:
            send_tracked_document(
                message.chat.id,
                f,
                caption=f"📊 <b>Daily Proof Report ({date.today().isoformat()})</b>\nAccount-wise links & completion status.",
                parse_mode="HTML"
            )
    else:
        send_tracked_message(message.chat.id, "Excel report create nahi ho saki.", reply_markup=get_main_keyboard())

# ----------------- CLEAR CHAT FEATURE -----------------
@bot.message_handler(func=lambda msg: msg.text == "🧹 Clear Chat" or msg.text == "/clear")
def btn_clear_chat(message):
    text = (
        "<b>🧹 CHAT CLEAR MENU</b>\n\n"
        "Daily proof checking complete hone ke baad chat ko clean karein:\n\n"
        "• <b>Clear Single Account Proof Chat:</b> Kisi ek account (e.g. Account #1) ke saare proof screenshots & links delete karein.\n"
        "• <b>Clear All Chat History:</b> Aaj ke saare messages, proof images & reports 1-click me clean karein."
    )
    send_tracked_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_clear_chat_inline_kb())

# ----------------- ACCOUNT NUMBER INPUT -----------------
@bot.message_handler(func=lambda msg: msg.text and msg.text.strip().isdigit())
def handle_acc_number_input(message):
    chat_id = message.chat.id
    acc_num = int(message.text.strip())
    if acc_num < 1 or acc_num > 100:
        bot.reply_to(message, "Account number 1 se 100 ke beech hona chahiye.")
        return
        
    session = user_sessions.get(chat_id, {})
    action = session.get("action")
    
    # Clear Single Account state
    if action == "waiting_clear_acc_num":
        user_sessions.pop(chat_id, None)
        target_acc = str(acc_num)
        tracker = load_tracker()
        cid = str(chat_id)
        acc_msgs = tracker.get(cid, {}).get("by_acc", {}).get(target_acc, [])
        if not acc_msgs:
            send_tracked_message(chat_id, f"ℹ️ Account #{target_acc} ke liye manager bot me koi tracked messages nahi mile.", reply_markup=get_main_keyboard())
            return
        status_msg = bot.send_message(chat_id, f"🧹 Account #{target_acc} ke proofs chat se delete ho rahe hain...")
        deleted = delete_messages(chat_id, acc_msgs)
        tracker[cid]["by_acc"][target_acc] = []
        tracker[cid]["all"] = [m for m in tracker[cid]["all"] if m not in acc_msgs]
        save_tracker(tracker)
        try:
            bot.delete_message(chat_id, status_msg.message_id)
        except Exception:
            pass
        send_tracked_message(chat_id, f"✅ <b>Account #{target_acc}</b> ke {deleted} proof messages & photos chat se successfully clear kar diye gaye! 🧹", parse_mode="HTML", reply_markup=get_main_keyboard())
        return

    # View Account
    if action == "waiting_acc_num_view":
        user_sessions.pop(chat_id, None)
        show_account_proof(chat_id, acc_num)
        return

    # Upload Account (Default if not viewing)
    user_sessions[chat_id] = {
        "action": "uploading",
        "acc_num": acc_num,
        "step": 1,
        "temp_data": {}
    }
    prompt_for_topic(chat_id, acc_num, 1)

def prompt_for_topic(chat_id, acc_num, topic_num):
    topic_title = TOPIC_TITLES.get(topic_num)
    text = (
        f"<b>📤 ACCOUNT #{acc_num} — TOPIC {topic_num} PROOF</b>\n"
        f"<b>Theme:</b> {topic_title}\n\n"
        f"Kripya is topic ka <b>Screenshot (Photo)</b> bhejo.\n"
        f"<i>Tip: Photo ke Caption me live Tweet ka Link likh kar bhej sakte ho, ya pehle photo aur agle message me link bhej dena.</i>"
    )
    send_tracked_message(chat_id, text, acc_num=acc_num, parse_mode="HTML")

# ----------------- PHOTO PROOF HANDLER -----------------
@bot.message_handler(content_types=["photo"])
def handle_photo_proof(message):
    chat_id = message.chat.id
    session = user_sessions.get(chat_id)
    if not session or session.get("action") != "uploading":
        send_tracked_message(chat_id, "Pehle <b>📤 Upload Proof</b> daba kar Account select karein.", parse_mode="HTML")
        return
        
    acc_num = session["acc_num"]
    step = session["step"]
    photo = message.photo[-1]
    file_id = photo.file_id
    
    try:
        file_info = bot.get_file(file_id)
        downloaded = bot.download_file(file_info.file_path)
        filename = f"acc_{acc_num}_t{step}_{date.today().isoformat()}.jpg"
        local_path = os.path.join(PROOFS_DIR, filename)
        with open(local_path, "wb") as f:
            f.write(downloaded)
    except Exception as e:
        local_path = ""
        print("Save error:", e)
        
    session["temp_data"][f"t{step}_file_id"] = file_id
    session["temp_data"][f"t{step}_path"] = local_path
    
    # Check if link was in caption
    if message.caption and ("http://" in message.caption or "https://" in message.caption):
        link = ""
        for word in message.caption.split():
            if word.startswith("http://") or word.startswith("https://"):
                link = word
                break
        session["temp_data"][f"t{step}_link"] = link
        send_tracked_message(chat_id, f"✅ Topic {step} Screenshot & Link dono receive ho gaye!", acc_num=acc_num)
        proceed_to_next_step(chat_id)
        return
        
    session["action"] = "waiting_link"
    send_tracked_message(
        chat_id,
        f"✅ Topic {step} Screenshot receive ho gaya!\n\nAb is tweet ka <b>Live Link</b> bhejo:\nExample: <code>https://x.com/username/status/...</code>",
        acc_num=acc_num,
        parse_mode="HTML"
    )

# ----------------- TEXT FLOW (FOR LINKS & COMMANDS) -----------------
@bot.message_handler(func=lambda msg: True)
def handle_text_flow(message):
    chat_id = message.chat.id
    session = user_sessions.get(chat_id)
    text = message.text.strip()
    
    if not session:
        if text.startswith("http://") or text.startswith("https://"):
            bot.reply_to(message, "Pehle <b>📤 Upload Proof</b> daba kar account number select karein.", reply_markup=get_main_keyboard(), parse_mode="HTML")
            return
        bot.reply_to(message, "Niche diye gaye buttons se shuru karein:", reply_markup=get_main_keyboard())
        return
        
    if session.get("action") == "waiting_link":
        if text.startswith("http://") or text.startswith("https://"):
            step = session["step"]
            acc_num = session["acc_num"]
            session["temp_data"][f"t{step}_link"] = text
            send_tracked_message(chat_id, f"✅ Topic {step} Link saved!", acc_num=acc_num)
            proceed_to_next_step(chat_id)
            return
        else:
            bot.reply_to(message, "⚠️ Kripya valid Link bhejo jo http:// ya https:// se shuru ho.")
            return

    if session.get("action") in ["waiting_acc_num_upload", "waiting_acc_num_view", "waiting_clear_acc_num"]:
        if text.isdigit():
            handle_acc_number_input(message)
            return
        else:
            bot.reply_to(message, "Kripya valid number bhejo (1 se 100).")
            return

def proceed_to_next_step(chat_id):
    session = user_sessions.get(chat_id)
    if not session:
        return
    acc_num = session["acc_num"]
    current_step = session["step"]
    
    if current_step < 3:
        session["step"] = current_step + 1
        session["action"] = "uploading"
        prompt_for_topic(chat_id, acc_num, session["step"])
        return
        
    # All 3 topics completed! Save to DB
    db = load_db()
    key = str(acc_num)
    temp = session["temp_data"]
    today = date.today().isoformat()
    
    db[key] = {
        "account": acc_num,
        "date": today,
        "completed": True,
        "topics": {
            "1": {
                "file_id": temp.get("t1_file_id", ""),
                "file_path": temp.get("t1_path", ""),
                "link": temp.get("t1_link", "")
            },
            "2": {
                "file_id": temp.get("t2_file_id", ""),
                "file_path": temp.get("t2_path", ""),
                "link": temp.get("t2_link", "")
            },
            "3": {
                "file_id": temp.get("t3_file_id", ""),
                "file_path": temp.get("t3_path", ""),
                "link": temp.get("t3_link", "")
            }
        }
    }
    save_db(db)
    user_sessions.pop(chat_id, None)
    
    send_tracked_message(
        chat_id,
        f"🎉 <b>ACCOUNT #{acc_num} KA FULL PROOF SUBMIT HO GAYA!</b>\n\n"
        f"• Topic 1: Saved\n"
        f"• Topic 2: Saved\n"
        f"• Topic 3: Saved\n"
        f"• Excel Report auto-updated!\n\n"
        f"Proof dekhne ke liye <b>📂 View Account Proof</b> dabayein.",
        acc_num=acc_num,
        parse_mode="HTML",
        reply_markup=get_main_keyboard()
    )

# ----------------- SHOW ACCOUNT PROOF -----------------
def show_account_proof(chat_id, acc_num):
    db = load_db()
    key = str(acc_num)
    data = db.get(key)
    if not data or not data.get("topics"):
        send_tracked_message(
            chat_id,
            f"❌ <b>Account #{acc_num} ka koi proof save nahi mila.</b>\nNaya proof daalne ke liye <b>📤 Upload Proof</b> dabayein.",
            parse_mode="HTML",
            reply_markup=get_main_keyboard()
        )
        return
        
    topics = data.get("topics", {})
    status_str = "✅ Fully Completed" if data.get("completed") else "⏳ Incomplete"
    header = (
        f"<b>📂 ACCOUNT #{acc_num} PROOF RECORD</b>\n"
        f"Date: <code>{data.get('date', 'Today')}</code>\n"
        f"Status: <b>{status_str}</b>\n\n"
        f"<i>Teeno photos gallery me save karne ke liye photo par tap karke 'Save to Gallery' karein.</i>"
    )
    send_tracked_message(chat_id, header, acc_num=acc_num, parse_mode="HTML")
    
    all_links = []
    for t_num in [1, 2, 3]:
        t_data = topics.get(str(t_num), {})
        title = TOPIC_TITLES.get(t_num)
        link = t_data.get("link", "No link")
        file_id = t_data.get("file_id")
        file_path = t_data.get("file_path")
        
        if link and link != "No link":
            all_links.append(f"Topic {t_num}: {link}")
            
        caption = f"<b>📌 Topic {t_num}: {title}</b>\n🔗 Link: <code>{link}</code>"
        sent = False
        if file_id:
            try:
                send_tracked_photo(chat_id, file_id, acc_num=acc_num, caption=caption, parse_mode="HTML")
                sent = True
            except Exception:
                pass
        if not sent and file_path and os.path.exists(file_path):
            try:
                with open(file_path, "rb") as photo:
                    send_tracked_photo(chat_id, photo, acc_num=acc_num, caption=caption, parse_mode="HTML")
                    sent = True
            except Exception:
                pass
        if not sent:
            send_tracked_message(chat_id, f"{caption}\n<i>(Photo unavailable)</i>", acc_num=acc_num, parse_mode="HTML")
            
    markup = types.InlineKeyboardMarkup(row_width=1)
    if all_links:
        combined_links = "\n".join(all_links)
        if len(combined_links) <= 256:
            try:
                markup.add(types.InlineKeyboardButton(text="📋 Copy All 3 Links", copy_text=types.CopyTextButton(combined_links)))
            except Exception:
                pass
                
    next_acc = (acc_num + 1) if acc_num < 100 else 1
    markup.add(types.InlineKeyboardButton(text=f"Next ➔ Account #{next_acc} Proof", callback_data=f"view_acc_{next_acc}"))
    send_tracked_message(chat_id, f"Actions for Account #{acc_num}:", acc_num=acc_num, reply_markup=markup)

# ----------------- CALLBACK HANDLER -----------------
@bot.callback_query_handler(func=lambda call: True)
def handle_cb(call):
    data = call.data
    chat_id = call.message.chat.id
    
    if data.startswith("view_acc_"):
        acc_num = int(data.split("_")[-1])
        bot.answer_callback_query(call.id)
        show_account_proof(chat_id, acc_num)
        return

    # Clear Chat: Single Account Prompt
    if data == "mgr_clear_acc_prompt":
        bot.answer_callback_query(call.id)
        user_sessions[chat_id] = {"action": "waiting_clear_acc_num"}
        send_tracked_message(
            chat_id,
            "<b>Kis Account ke proofs chat se clear karne hain?</b>\nAccount number bhejo (1 se 100):\nExample: <code>1</code> ya <code>15</code>",
            parse_mode="HTML"
        )
        return

    # Clear Chat: All Confirm
    if data == "mgr_clear_all_confirm":
        bot.answer_callback_query(call.id)
        markup = types.InlineKeyboardMarkup(row_width=2)
        b_yes = types.InlineKeyboardButton("✅ Haan, Clear All Messages", callback_data="mgr_clear_all_execute")
        b_no = types.InlineKeyboardButton("❌ Cancel", callback_data="mgr_clear_cancel")
        markup.add(b_yes, b_no)
        send_tracked_message(
            chat_id,
            "⚠️ <b>CONFIRM: DAILY CHAT CLEAR</b>\n\nKya aap sach me manager bot ke saare messages, proof images aur documents chat se delete karna chahte hain?",
            parse_mode="HTML",
            reply_markup=markup
        )
        return

    # Clear Chat: All Execute
    if data == "mgr_clear_all_execute":
        bot.answer_callback_query(call.id, text="Saari chat clear ho rahi hai... 🧹")
        tracker = load_tracker()
        cid = str(chat_id)
        all_msgs = tracker.get(cid, {}).get("all", [])
        
        status_msg = bot.send_message(chat_id, "🧹 Daily chat history delete ho rahi hai...")
        deleted = delete_messages(chat_id, all_msgs)
        tracker[cid] = {"all": [], "by_acc": {}}
        save_tracker(tracker)
        try:
            bot.delete_message(chat_id, status_msg.message_id)
        except Exception:
            pass
        send_tracked_message(
            chat_id,
            f"✨ <b>Daily chat clean complete!</b>\nTotal {deleted} proof messages & photos delete kar diye gaye.\n\nAgle din ka kaam shuru karne ke liye niche buttons use karein 👇",
            parse_mode="HTML",
            reply_markup=get_main_keyboard()
        )
        return

    # Clear Chat: Cancel
    if data == "mgr_clear_cancel":
        bot.answer_callback_query(call.id, text="Cancelled")
        try:
            bot.delete_message(chat_id, call.message.message_id)
        except Exception:
            pass
        return

if __name__ == "__main__":
    print("=" * 60)
    print(">> Enhanced Proof Manager Bot (@Mangerprofbot) is RUNNING!")
    print(f">> Token: {TOKEN}")
    print("=" * 60)
    bot.infinity_polling(none_stop=True, timeout=60)
