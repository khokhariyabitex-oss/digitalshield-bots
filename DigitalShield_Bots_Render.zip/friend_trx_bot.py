# -*- coding: utf-8 -*-
"""
Digital Shield Daily Post & Graphic Generator Bot (@Dailytrxmatebot)
Updated with:
- Topic 1: Fixed exact text with dynamic referral link
- Topic 2: Viral X/Twitter posts for Digital Shield Wallet APP & Features
- Topic 3: Viral X/Twitter posts for DSpay Payment Services & USDT Gateway
- Topic 3 Graphic: 1080x1080 HD Human-crafted Graphics for DSpay & Web3 Payments (6 Layouts, 6 Themes)
- 100% UTF-8 Clean Formatting & 1-Tap Clipboard Copy
"""

import os
import sys
import json
import time
from datetime import datetime

# Ensure local packages are on sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PACKAGES_DIR = os.path.join(BASE_DIR, "packages_runtime")
PYZ_DIR = os.path.join(PACKAGES_DIR, "PYZ.pyz_extracted")
if BASE_DIR in sys.path:
    sys.path.remove(BASE_DIR)
sys.path.insert(0, BASE_DIR)
for p in [PACKAGES_DIR, PYZ_DIR]:
    if os.path.exists(p) and p not in sys.path:
        sys.path.append(p)

import telebot
from telebot import types
from PIL import Image, ImageDraw, ImageFont

DATA_DIR = os.path.join(BASE_DIR, "data_trx")
PHOTOS_DIR = os.path.join(DATA_DIR, "photos")
LINKS_FILE = os.path.join(DATA_DIR, "permanent_links.json")
TRACKER_FILE = os.path.join(DATA_DIR, "tracked_messages.json")
TOKEN = os.environ.get("TRX_BOT_TOKEN", "8649679044:AAFRG5F750c_y3xWex6lPET1OZf4Hng4GLk").strip()

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PHOTOS_DIR, exist_ok=True)

bot = telebot.TeleBot(TOKEN)
user_states = {}

# ----------------- TRACKED MESSAGES (FOR CLEAR CHAT) -----------------
def load_tracker():
    if os.path.exists(TRACKER_FILE):
        try:
            with open(TRACKER_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_tracker(tracker):
    try:
        with open(TRACKER_FILE, "w", encoding="utf-8") as f:
            json.dump(tracker, f, indent=2)
    except Exception:
        pass

def track_message(chat_id, msg_id, acc_num=None):
    tracker = load_tracker()
    cid = str(chat_id)
    if cid not in tracker:
        tracker[cid] = {"all": [], "by_acc": {}}
    if msg_id not in tracker[cid]["all"]:
        tracker[cid]["all"].append(msg_id)
    if acc_num is not None:
        anum = str(acc_num)
        if anum not in tracker[cid]["by_acc"]:
            tracker[cid]["by_acc"][anum] = []
        if msg_id not in tracker[cid]["by_acc"][anum]:
            tracker[cid]["by_acc"][anum].append(msg_id)
    save_tracker(tracker)

def send_tracked_message(chat_id, text, acc_num=None, **kwargs):
    msg = bot.send_message(chat_id, text, **kwargs)
    track_message(chat_id, msg.message_id, acc_num)
    return msg

def send_tracked_photo(chat_id, photo, acc_num=None, **kwargs):
    msg = bot.send_photo(chat_id, photo, **kwargs)
    track_message(chat_id, msg.message_id, acc_num)
    return msg

def delete_messages(chat_id, msg_ids):
    count = 0
    for mid in msg_ids:
        try:
            bot.delete_message(chat_id, mid)
            count += 1
            time.sleep(0.02)
        except Exception:
            pass
    return count

# ----------------- PERMANENT LINKS -----------------
def load_permanent_links():
    if os.path.exists(LINKS_FILE):
        try:
            with open(LINKS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_permanent_links(links_dict):
    with open(LINKS_FILE, "w", encoding="utf-8") as f:
        json.dump(links_dict, f, indent=2, ensure_ascii=False)

# ----------------- FONTS HELPER -----------------
def get_font(size, bold=False):
    candidates = (
        ["arialbd.ttf", "segoeuib.ttf", "tahomabd.ttf", "calibrib.ttf", "DejaVuSans-Bold.ttf"]
        if bold
        else ["arial.ttf", "segoeui.ttf", "tahoma.ttf", "calibri.ttf", "DejaVuSans.ttf"]
    )
    for c in candidates:
        try:
            return ImageFont.truetype(c, size)
        except Exception:
            continue
    try:
        return ImageFont.load_default(size=size)
    except Exception:
        return ImageFont.load_default()

# ----------------- VECTOR GRAPHIC HELPERS (REAL HUMAN DESIGN) -----------------
def draw_gradient(draw, width, height, c_top, c_bottom):
    for y in range(0, height, 4):
        ratio = y / height
        r = int(c_top[0] * (1 - ratio) + c_bottom[0] * ratio)
        g = int(c_top[1] * (1 - ratio) + c_bottom[1] * ratio)
        b = int(c_top[2] * (1 - ratio) + c_bottom[2] * ratio)
        draw.line([(0, y), (width, y)], fill=(r, g, b), width=4)

def draw_grid_dots(draw, width, height):
    for gx in range(50, width, 60):
        for gy in range(50, height, 60):
            if (gx + gy) % 120 == 0:
                draw.ellipse([gx - 1, gy - 1, gx + 1, gy + 1], fill=(255, 255, 255))

def draw_vector_checkmark(draw, cx, cy, radius, color):
    draw.ellipse([cx - radius, cy - radius, cx + radius, cy + radius], fill=color)
    pts = [(cx - 6, cy), (cx - 2, cy + 5), (cx + 7, cy - 5)]
    draw.line([pts[0], pts[1]], fill=(255, 255, 255), width=3)
    draw.line([pts[1], pts[2]], fill=(255, 255, 255), width=3)

def draw_usdt_symbol(draw, cx, cy, radius, color):
    draw.ellipse([cx - radius, cy - radius, cx + radius, cy + radius], outline=color, width=3)
    bar_w = int(radius * 0.9)
    stem_h = int(radius * 0.9)
    draw.line([(cx - bar_w // 2, cy - stem_h // 3), (cx + bar_w // 2, cy - stem_h // 3)], fill=color, width=4)
    draw.line([(cx, cy - stem_h // 3), (cx, cy + stem_h // 2)], fill=color, width=4)
    draw.ellipse([cx - bar_w // 2, cy - 3, cx + bar_w // 2, cy + 5], outline=color, width=2)

def draw_shield_icon(draw, cx, cy, size, color):
    w = size // 2
    h = int(size * 0.65)
    pts = [
        (cx - w, cy - h // 2),
        (cx + w, cy - h // 2),
        (cx + w, cy),
        (cx, cy + h // 2),
        (cx - w, cy)
    ]
    draw.polygon(pts, outline=color, width=3)

# ----------------- DSPAY THEME PALETTES -----------------
THEME_PALETTES = [
    {
        "name": "Tether Mint Emerald",
        "bg_top": (10, 26, 20),
        "bg_bottom": (14, 40, 30),
        "primary": (38, 161, 123),
        "secondary": (110, 231, 183),
        "card_fill": (15, 32, 26),
        "card_border": (35, 78, 60),
        "badge_text": "[ DSPAY • USDT PAYMENT GATEWAY ]",
        "tagline": "INSTANT BORDERLESS SETTLEMENT"
    },
    {
        "name": "Cyber Electric Cyan",
        "bg_top": (10, 18, 34),
        "bg_bottom": (16, 28, 52),
        "primary": (0, 210, 255),
        "secondary": (130, 230, 255),
        "card_fill": (16, 30, 48),
        "card_border": (36, 68, 105),
        "badge_text": "[ NEXT-GEN WEB3 MERCHANT PAYMENTS ]",
        "tagline": "MULTI-CHAIN USDT PROCESSING"
    },
    {
        "name": "Obsidian Imperial Gold",
        "bg_top": (26, 20, 10),
        "bg_bottom": (44, 32, 14),
        "primary": (245, 158, 11),
        "secondary": (253, 224, 71),
        "card_fill": (36, 28, 18),
        "card_border": (85, 62, 34),
        "badge_text": "[ GLOBAL MERCHANT SETTLEMENT ]",
        "tagline": "ZERO CHARGEBACK & VOLATILITY RISK"
    },
    {
        "name": "Deep Royal Purple",
        "bg_top": (20, 12, 34),
        "bg_bottom": (32, 18, 52),
        "primary": (168, 85, 247),
        "secondary": (216, 180, 254),
        "card_fill": (28, 18, 48),
        "card_border": (72, 45, 110),
        "badge_text": "[ DECENTRALIZED PAYMENT RAILS ]",
        "tagline": "PLUG & PLAY WEB3 CHECKOUT API"
    },
    {
        "name": "Modern Slate Teal",
        "bg_top": (12, 24, 28),
        "bg_bottom": (18, 38, 44),
        "primary": (20, 184, 166),
        "secondary": (94, 234, 212),
        "card_fill": (18, 32, 38),
        "card_border": (36, 72, 82),
        "badge_text": "[ SECURE E-COMMERCE CHECKOUT ]",
        "tagline": "TRC-20 / ERC-20 COMPLIANT"
    },
    {
        "name": "Crimson Ruby Shield",
        "bg_top": (26, 10, 14),
        "bg_bottom": (42, 15, 22),
        "primary": (244, 63, 94),
        "secondary": (251, 146, 160),
        "card_fill": (32, 16, 22),
        "card_border": (84, 32, 44),
        "badge_text": "[ ENTERPRISE PAYMENT GATEWAY ]",
        "tagline": "MILITARY-GRADE FRAUD PROTECTION"
    }
]

# ----------------- TOPIC 3: DSPAY GRAPHIC GENERATOR (6 DISTINCT HUMAN-DESIGNED FORMATS) -----------------
def generate_dspay_graphic(account_num):
    photo_file = os.path.join(PHOTOS_DIR, f"dspay_acc_{account_num}.png")
    width, height = 1080, 1080

    day_num = datetime.now().toordinal()
    theme_idx = (account_num + day_num - 1) % len(THEME_PALETTES)
    theme = THEME_PALETTES[theme_idx]
    layout_format = (account_num + (day_num % 6) - 1) % 6

    img = Image.new("RGB", (width, height), color=theme["bg_top"])
    draw = ImageDraw.Draw(img)
    draw_gradient(draw, width, height, theme["bg_top"], theme["bg_bottom"])
    draw_grid_dots(draw, width, height)

    border_col = theme["card_border"]
    primary_col = theme["primary"]
    sec_col = theme["secondary"]
    card_fill = theme["card_fill"]

    font_hero = get_font(52, bold=True)
    font_subhero = get_font(34, bold=True)
    font_title = get_font(30, bold=True)
    font_bold_body = get_font(26, bold=True)
    font_body = get_font(24, bold=False)
    font_small = get_font(20, bold=True)
    font_tiny = get_font(17, bold=False)

    # Outer Frame with Accent Brackets
    draw.rectangle([35, 35, width - 35, height - 35], outline=border_col, width=2)
    corner_len = 40
    for cx, cy in [(35, 35), (width - 35, 35), (35, height - 35), (width - 35, height - 35)]:
        dx = corner_len if cx == 35 else -corner_len
        dy = corner_len if cy == 35 else -corner_len
        draw.line([(cx, cy), (cx + dx, cy)], fill=primary_col, width=4)
        draw.line([(cx, cy), (cx, cy + dy)], fill=primary_col, width=4)

    # ----------------- LAYOUT 0: MERCHANT POS & INSTANT CHECKOUT TERMINAL -----------------
    if layout_format == 0:
        badge_w, badge_h = 600, 50
        bx1 = (width - badge_w) // 2
        draw.rounded_rectangle([bx1, 65, bx1 + badge_w, 65 + badge_h], radius=25, fill=card_fill, outline=primary_col, width=2)
        draw.text((width // 2, 90), theme["badge_text"], fill=sec_col, font=font_small, anchor="mm")

        draw.text((width // 2, 160), "DSPAY PAYMENT SERVICES", fill=(255, 255, 255), font=font_hero, anchor="mm")
        draw.text((width // 2, 218), "NEXT-GEN USDT MERCHANT PAYMENT GATEWAY", fill=primary_col, font=font_title, anchor="mm")

        draw.rounded_rectangle([90, 265, 990, 560], radius=20, fill=card_fill, outline=primary_col, width=3)
        draw_usdt_symbol(draw, 170, 345, 42, (38, 161, 123))
        draw.text((240, 325), "USDT ACCEPTED HERE", fill=(255, 255, 255), font=font_subhero)
        draw.text((240, 368), "TRC-20 & ERC-20 Instant On-Chain Processing", fill=sec_col, font=font_body)

        draw.line([(130, 420), (950, 420)], fill=border_col, width=1)

        pos_stats = [
            ("SETTLEMENT SPEED", "< 1 SECOND"),
            ("CHARGEBACK RISK", "0% ZERO FRAUD"),
            ("PROCESSING FEE", "ULTRA LOW GAS")
        ]
        stat_x = [130, 430, 730]
        for i, (lbl, val) in enumerate(pos_stats):
            sx = stat_x[i]
            draw.text((sx, 445), lbl, fill=(148, 163, 184), font=font_tiny)
            draw.text((sx, 485), val, fill=(52, 211, 153) if i == 0 else (255, 255, 255), font=font_bold_body)

        draw.rounded_rectangle([90, 595, 990, 845], radius=18, fill=(15, 23, 42), outline=border_col, width=2)
        draw.text((width // 2, 635), "WHY GLOBAL BUSINESSES CHOOSE DSPAY", fill=primary_col, font=font_title, anchor="mm")

        features = [
            ("Instant Multi-Chain USDT Rails", "Receive funds directly to your wallet without intermediary delays"),
            ("Global Borderless Customers", "Accept crypto payments from customers anywhere in the world 24/7"),
            ("Automated Merchant Accounting", "Real-time webhooks, transaction tracking & seamless API integration")
        ]
        fy = 695
        for h_txt, b_txt in features:
            draw_vector_checkmark(draw, 130, fy + 8, 12, (16, 185, 129))
            draw.text((155, fy), h_txt, fill=(255, 255, 255), font=font_bold_body)
            draw.text((155, fy + 26), b_txt, fill=(148, 163, 184), font=font_tiny)
            fy += 50

        draw.rounded_rectangle([90, 880, 990, 990], radius=16, fill=card_fill, outline=border_col, width=2)
        draw.text((125, 935), f"TERMINAL ID: DSPAY-MERCHANT-ACC{account_num:03d}", fill=(255, 255, 255), font=font_title, anchor="lm")
        draw.text((955, 935), "[ 100% VERIFIED GATEWAY ]", fill=(52, 211, 153), font=font_small, anchor="rm")

    # ----------------- LAYOUT 1: FINTECH NEO-GATEWAY SHOWCASE -----------------
    elif layout_format == 1:
        draw.rounded_rectangle([90, 60, 990, 120], radius=14, fill=card_fill, outline=border_col, width=1)
        draw.text((125, 90), "[+] DSPAY WEB3 INFRASTRUCTURE: LIVE", fill=(52, 211, 153), font=font_small, anchor="lm")
        draw.text((955, 90), "SETTLEMENT: 100% USDT STABLECOIN", fill=sec_col, font=font_small, anchor="rm")

        draw.text((width // 2, 175), "USDT PAYMENT GATEWAY", fill=(255, 255, 255), font=font_hero, anchor="mm")
        draw.text((width // 2, 235), "ENTERPRISE CRYPTO PAYMENTS POWERED BY DIGITAL SHIELD", fill=primary_col, font=font_title, anchor="mm")

        card_w = 280
        cx_pos = [90, 400, 710]
        cards = [
            ("CURRENCY", "USDT (TRC/ERC)", "Zero Volatility"),
            ("SETTLEMENT", "REAL-TIME", "Instant Cashout"),
            ("COVERAGE", "GLOBAL 200+", "Zero Border Limits")
        ]
        for idx, (c_lbl, c_val, c_sub) in enumerate(cards):
            x1 = cx_pos[idx]
            x2 = x1 + card_w
            draw.rounded_rectangle([x1, 280, x2, 440], radius=16, fill=card_fill, outline=primary_col if idx == 1 else border_col, width=2)
            draw.text((x1 + card_w // 2, 315), c_lbl, fill=(148, 163, 184), font=font_tiny, anchor="mm")
            draw.text((x1 + card_w // 2, 365), c_val, fill=(52, 211, 153) if idx == 1 else (255, 255, 255), font=get_font(24, bold=True), anchor="mm")
            draw.text((x1 + card_w // 2, 408), c_sub, fill=sec_col, font=font_tiny, anchor="mm")

        draw.rounded_rectangle([90, 475, 990, 845], radius=18, fill=(15, 23, 42), outline=border_col, width=2)
        draw.text((width // 2, 515), "SEAMLESS 3-STEP MERCHANT INTEGRATION", fill=primary_col, font=font_title, anchor="mm")
        draw.line([(150, 545), (930, 545)], fill=border_col, width=1)

        steps = [
            ("STEP 1", "Generate Merchant API Key in Digital Shield App"),
            ("STEP 2", "Embed DSpay Checkout Widget on your website or dApp"),
            ("STEP 3", "Receive instant USDT transfers directly to your wallet")
        ]
        sy = 600
        for s_idx, s_txt in steps:
            draw.rounded_rectangle([130, sy - 5, 235, sy + 35], radius=8, fill=card_fill, outline=primary_col, width=1)
            draw.text((182, sy + 15), s_idx, fill=primary_col, font=font_small, anchor="mm")
            draw.text((255, sy + 15), s_txt, fill=(226, 232, 240), font=font_bold_body, anchor="lm")
            sy += 78

        draw.rounded_rectangle([90, 880, 990, 990], radius=16, fill=card_fill, outline=primary_col, width=2)
        draw.text((125, 935), f"DSPAY ACCOUNT #{account_num:03d}", fill=(255, 255, 255), font=font_title, anchor="lm")
        draw.text((955, 935), "[ ULTRA SECURE WEB3 PAY ]", fill=primary_col, font=font_small, anchor="rm")

    # ----------------- LAYOUT 2: TRADITIONAL VS DSPAY COMPARISON -----------------
    elif layout_format == 2:
        badge_w, badge_h = 560, 50
        bx1 = (width - badge_w) // 2
        draw.rounded_rectangle([bx1, 65, bx1 + badge_w, 65 + badge_h], radius=25, fill=card_fill, outline=primary_col, width=2)
        draw.text((width // 2, 90), "[ MERCHANT ADVANTAGE REPORT ]", fill=primary_col, font=font_small, anchor="mm")

        draw.text((width // 2, 165), "WHY SWITCH TO DSPAY?", fill=(255, 255, 255), font=font_hero, anchor="mm")
        draw.text((width // 2, 225), "TRADITIONAL PAYMENT PROCESSORS VS DSPAY USDT GATEWAY", fill=sec_col, font=font_title, anchor="mm")

        draw.rounded_rectangle([90, 275, 520, 845], radius=18, fill=(24, 18, 22), outline=(90, 36, 44), width=2)
        draw.text((305, 315), "TRADITIONAL GATEWAYS", fill=(244, 63, 94), font=font_title, anchor="mm")
        draw.line([(120, 345), (490, 345)], fill=(90, 36, 44), width=1)

        old_items = [
            ("Settlement Delay", "3 to 5 business days wait"),
            ("High Fees", "3% to 5% + hidden charges"),
            ("Chargeback Fraud", "High chargeback disputes"),
            ("Cross-Border Fees", "Heavy FX conversion cost"),
            ("Bank Frozen Funds", "Account holds & restrictions")
        ]
        oy = 385
        for o_h, o_d in old_items:
            draw.text((130, oy), f"- {o_h}:", fill=(251, 146, 160), font=font_bold_body)
            draw.text((130, oy + 26), o_d, fill=(160, 160, 160), font=font_tiny)
            oy += 88

        draw.rounded_rectangle([560, 275, 990, 845], radius=18, fill=card_fill, outline=primary_col, width=2)
        draw.text((775, 315), "DSPAY USDT GATEWAY", fill=(52, 211, 153), font=font_title, anchor="mm")
        draw.line([(590, 345), (960, 345)], fill=border_col, width=1)

        new_items = [
            ("Instant Settlement", "< 1 second wallet credit"),
            ("Ultra-Low Gas", "Fraction of a cent on TRON"),
            ("0% Chargebacks", "Irreversible on-chain settlement"),
            ("100% Borderless", "Global checkout with USDT"),
            ("Direct Self-Custody", "Your funds, your private keys")
        ]
        ny = 385
        for n_h, n_d in new_items:
            draw.text((600, ny), f"+ {n_h}:", fill=(52, 211, 153), font=font_bold_body)
            draw.text((600, ny + 26), n_d, fill=(226, 232, 240), font=font_tiny)
            ny += 88

        draw.rounded_rectangle([90, 880, 990, 990], radius=16, fill=card_fill, outline=border_col, width=2)
        draw.text((125, 935), f"MERCHANT ID: DS-USDT-2026-ACC{account_num:03d}", fill=(255, 255, 255), font=font_title, anchor="lm")
        draw.text((955, 935), "[ 0% CHARGEBACK GUARANTEE ]", fill=(52, 211, 153), font=font_small, anchor="rm")

    # ----------------- LAYOUT 3: WEB3 E-COMMERCE CHECKOUT MODAL -----------------
    elif layout_format == 3:
        badge_w, badge_h = 580, 50
        bx1 = (width - badge_w) // 2
        draw.rounded_rectangle([bx1, 65, bx1 + badge_w, 65 + badge_h], radius=25, fill=card_fill, outline=primary_col, width=2)
        draw.text((width // 2, 90), "[+] E-COMMERCE & WEB3 PAYMENTS [+]", fill=primary_col, font=font_small, anchor="mm")

        draw.text((width // 2, 170), "EMPOWER YOUR STORE WITH DSPAY", fill=(255, 255, 255), font=font_hero, anchor="mm")
        draw.text((width // 2, 230), "SEAMLESS USDT CHECKOUT FOR ONLINE & RETAIL STORES", fill=sec_col, font=font_title, anchor="mm")

        draw.rounded_rectangle([90, 280, 990, 570], radius=22, fill=(15, 23, 42), outline=primary_col, width=3)
        draw_shield_icon(draw, 170, 360, 70, primary_col)
        draw.text((230, 335), "DSPAY CHECKOUT GATEWAY", fill=(255, 255, 255), font=font_subhero)
        draw.text((230, 380), "Pay with USDT - Instant Settlement Verified", fill=(52, 211, 153), font=font_body)

        draw.rounded_rectangle([130, 435, 950, 535], radius=12, fill=card_fill, outline=border_col, width=1)
        draw.text((160, 465), "ACCEPTED NETWORKS:", fill=(148, 163, 184), font=font_tiny)
        draw.text((160, 498), "TRON TRC-20  |  ETHEREUM ERC-20  |  BNB CHAIN", fill=(255, 255, 255), font=font_bold_body)

        py = 605
        pillars = [
            ("ONE-CLICK API", "Quick integration into WooCommerce, Shopify or custom dApps"),
            ("MULTI-PLATFORM", "Supports online web store, mobile apps & in-person POS QR"),
            ("100% STABLE REVENUE", "Zero crypto market dip risk. Pure USDT 1:1 USD pricing")
        ]
        for p_title, p_desc in pillars:
            draw.rounded_rectangle([90, py, 990, py + 68], radius=12, fill=card_fill, outline=border_col, width=1)
            draw_vector_checkmark(draw, 125, py + 34, 12, primary_col)
            draw.text((155, py + 16), p_title, fill=primary_col, font=font_bold_body)
            draw.text((155, py + 42), p_desc, fill=(226, 232, 240), font=font_tiny)
            py += 80

        draw.rounded_rectangle([90, 880, 990, 990], radius=16, fill=card_fill, outline=border_col, width=2)
        draw.text((125, 935), f"PORTAL #0{account_num} VERIFIED", fill=primary_col, font=font_title, anchor="lm")
        draw.text((955, 935), "[ 24/7 GLOBAL CHECKOUT ]", fill=(52, 211, 153), font=font_small, anchor="rm")

    # ----------------- LAYOUT 4: ENTERPRISE SECURITY & INFRASTRUCTURE -----------------
    elif layout_format == 4:
        draw.rounded_rectangle([90, 60, 990, 120], radius=14, fill=card_fill, outline=border_col, width=1)
        draw.text((125, 90), "DSPAY ENTERPRISE ARCHITECTURE", fill=sec_col, font=font_small, anchor="lm")
        draw.text((955, 90), "STATUS: 99.99% SYSTEM UPTIME", fill=(52, 211, 153), font=font_small, anchor="rm")

        draw.text((width // 2, 175), "ENTERPRISE CRYPTO SETTLEMENT", fill=(255, 255, 255), font=font_hero, anchor="mm")
        draw.text((width // 2, 235), "INSTANT & REGULATED USDT GATEWAY FOR MODERN MERCHANTS", fill=primary_col, font=font_title, anchor="mm")

        quads = [
            ("END-TO-END ENCRYPTION", "Military-grade cryptographic protocols protecting all transaction hashes"),
            ("MULTI-SIGNATURE CUSTODY", "Private key safety architecture with zero centralized single-point-of-failure"),
            ("REAL-TIME WEBHOOK ENGINE", "Instant callback triggers for automated order fulfillment and shipping"),
            ("COMPREHENSIVE ANALYTICS", "Full merchant dashboard with revenue reports, volume charts & CSV exports")
        ]
        coords = [
            (90, 280, 520, 530),
            (560, 280, 990, 530),
            (90, 560, 520, 840),
            (560, 560, 990, 840)
        ]
        for idx, (q_title, q_desc) in enumerate(quads):
            x1, y1, x2, y2 = coords[idx]
            draw.rounded_rectangle([x1, y1, x2, y2], radius=16, fill=card_fill, outline=primary_col if idx == 0 else border_col, width=2)
            draw_shield_icon(draw, x1 + 45, y1 + 50, 40, primary_col)
            draw.text((x1 + 80, y1 + 38), f"0{idx + 1}", fill=(148, 163, 184), font=font_small)
            draw.text((x1 + 35, y1 + 95), q_title, fill=(255, 255, 255), font=font_title)
            words = q_desc.split()
            line1 = " ".join(words[:5])
            line2 = " ".join(words[5:11])
            line3 = " ".join(words[11:])
            draw.text((x1 + 35, y1 + 140), line1, fill=(203, 213, 225), font=font_body)
            if line2: draw.text((x1 + 35, y1 + 172), line2, fill=(203, 213, 225), font=font_body)
            if line3: draw.text((x1 + 35, y1 + 204), line3, fill=(203, 213, 225), font=font_body)

        draw.rounded_rectangle([90, 880, 990, 990], radius=16, fill=card_fill, outline=primary_col, width=2)
        draw.text((125, 935), f"SECURITY AUDIT: PASSED (ACC #{account_num:03d})", fill=(52, 211, 153), font=font_title, anchor="lm")
        draw.text((955, 935), "[ BANK-GRADE REVENUE RAILS ]", fill=sec_col, font=font_small, anchor="rm")

    # ----------------- LAYOUT 5: BOLD TYPOGRAPHY & HERO BENEFIT BANNER -----------------
    else:
        badge_w, badge_h = 520, 50
        bx1 = (width - badge_w) // 2
        draw.rounded_rectangle([bx1, 65, bx1 + badge_w, 65 + badge_h], radius=25, fill=card_fill, outline=primary_col, width=2)
        draw.text((width // 2, 90), "[+] THE FUTURE OF WEB3 PAYMENTS [+]", fill=primary_col, font=font_small, anchor="mm")

        draw.text((width // 2, 175), "ACCEPT USDT ANYWHERE", fill=(255, 255, 255), font=font_hero, anchor="mm")
        draw.text((width // 2, 235), "DSPAY - THE EASIEST CRYPTO GATEWAY FOR MERCHANTS", fill=sec_col, font=font_title, anchor="mm")

        draw.rounded_rectangle([90, 285, 990, 550], radius=20, fill=card_fill, outline=primary_col, width=3)
        draw.text((width // 2, 335), "SPEED  |  SECURITY  |  SIMPLICITY", fill=(148, 163, 184), font=font_small, anchor="mm")
        draw.text((width // 2, 405), "INSTANT USDT PAYOUTS", fill=(255, 255, 255), font=get_font(48, bold=True), anchor="mm")
        draw.text((width // 2, 465), "Eliminate 3-5% Card Processing Fees Forever", fill=(52, 211, 153), font=font_title, anchor="mm")
        draw.text((width // 2, 510), "Full Custody & Direct Wallet Settlements Guaranteed", fill=sec_col, font=font_tiny, anchor="mm")

        draw.rounded_rectangle([90, 585, 990, 845], radius=18, fill=(15, 23, 42), outline=border_col, width=2)
        draw.text((width // 2, 625), "START ACCEPTING USDT TODAY", fill=primary_col, font=font_title, anchor="mm")

        b_steps = [
            "1. Register merchant profile on Digital Shield App",
            "2. Connect your business wallet & configure settlement currency",
            "3. Start accepting payments instantly with 0% chargeback risk"
        ]
        by = 685
        for bs in b_steps:
            draw_vector_checkmark(draw, 130, by, 12, (16, 185, 129))
            draw.text((160, by), bs, fill=(226, 232, 240), font=font_bold_body, anchor="lm")
            by += 50

        draw.rounded_rectangle([90, 880, 990, 990], radius=16, fill=card_fill, outline=primary_col, width=2)
        draw.text((125, 935), f"ACCOUNT #{account_num:03d} AUTHORIZED", fill=primary_col, font=font_title, anchor="lm")
        draw.text((955, 935), "[ 100% GENUINE CRYPTO GATEWAY ]", fill=(52, 211, 153), font=font_small, anchor="rm")

    img.save(photo_file, "PNG", quality=95)
    return photo_file


# ----------------- TOPIC 1: FIXED TEXT (DYNAMIC REFERRAL LINK ONLY) -----------------
TOPIC1_BASE_TEXT = (
    "🔥 The Work To Earn Referral System is LIVE!\n\n"
    "💰 1 Point = 1 TRX\n\n"
    "🚀 Withdraw with just 2 Points!\n\n"
    "👥 Invite + Check In + Complete Tasks\n\n"
    "Earn Points every day and keep accumulating TRX!\n\n"
    "👇Join Work To Earn Now\n{link}"
)

# ----------------- TOPIC 2: VIRAL X/TWITTER POSTS FOR WALLET APP & FEATURES -----------------
# Categories covered: Digital Shield Wallet APP, Digital asset management, Wallet features, Web3 UX, Intro to APP
# Hashtags: #DigitalShield #DigitalShieldWallet #CryptoWallet #Web3Wallet #Crypto #Web3 #CryptoSecurity
TOPIC2_TEMPLATES = [
    # Category 1: Digital Shield Wallet APP
    "Tired of complex crypto wallets? Digital Shield Wallet APP gives you full self-custody with zero headaches. Store, swap & track your portfolio in real time! 🛡️⚡\n\n#DigitalShield #DigitalShieldWallet #CryptoWallet #Web3",
    "Your crypto deserves elite protection. Digital Shield Wallet APP combines military-grade security with an ultra-sleek interface. True ownership begins here! 💎🔒\n\n#DigitalShieldWallet #CryptoWallet #Web3Wallet #Crypto",
    "Take control of your crypto future with Digital Shield Wallet APP. Easy multi-chain transfers, instant swaps and zero custodial risk. Step into Web3 today! 🚀\n\n#DigitalShield #CryptoWallet #Web3Wallet #CryptoSecurity",
    "Security meets simplicity. Digital Shield Wallet APP is engineered for modern crypto traders who refuse to compromise on safety. Get the app now! 🛡️✨\n\n#DigitalShieldWallet #Crypto #Web3 #CryptoWallet #CryptoSecurity",

    # Category 2: Digital Asset Management
    "Managing Bitcoin, TRX & USDT across separate apps is exhausting. Digital Shield unifies your digital asset management in one clean dashboard. Total control! 📊💰\n\n#DigitalShield #DigitalShieldWallet #Crypto #Web3 #CryptoSecurity",
    "Effortless digital asset management is finally here. Track balances, monitor market trends, and secure your tokens all in one place with Digital Shield! 📈🛡️\n\n#DigitalShield #CryptoWallet #Web3Wallet #Crypto #CryptoSecurity",
    "Never lose track of your portfolio again. Digital Shield delivers pro-grade digital asset management with real-time analytics & multi-currency tracking! 💼⚡\n\n#DigitalShieldWallet #CryptoWallet #Web3 #Crypto #CryptoSecurity",
    "Smart investors know asset management requires smart tools. Digital Shield Wallet gives you full visibility over every single token with zero stress! 🌐🔥\n\n#DigitalShield #DigitalShieldWallet #CryptoWallet #Web3Wallet",

    # Category 3: Wallet Features
    "Biometric login, multi-chain swaps, hardware-level cold storage integration & instant push alerts. Digital Shield Wallet is packed with elite Web3 features! ⚡📱\n\n#DigitalShieldWallet #CryptoWallet #Web3Wallet #CryptoSecurity",
    "Instant token swaps at the lowest network fees. Digital Shield Wallet features make managing on-chain assets faster and cheaper than ever before! 🔄💸\n\n#DigitalShield #DigitalShieldWallet #CryptoWallet #Web3 #Crypto",
    "Built-in dApp browser, custom gas control, and seamless TRC-20 & ERC-20 support. Discover the powerful features of Digital Shield Wallet APP! 🚀🛡️\n\n#DigitalShield #DigitalShieldWallet #Web3Wallet #CryptoWallet #Web3",
    "From auto-detecting tokens to advanced private key encryption, Digital Shield Wallet features put institutional security directly in your hands! 🔐✨\n\n#CryptoSecurity #DigitalShield #DigitalShieldWallet #Web3Wallet",

    # Category 4: Web3 Wallet User Experience
    "Web3 shouldn't feel like rocket science. Digital Shield Wallet APP delivers buttery-smooth UX, instant transaction signing, and zero confusing jargon! 💎👌\n\n#Web3Wallet #DigitalShield #DigitalShieldWallet #Crypto #Web3",
    "The cleanest Web3 wallet experience in crypto. Clean navigation, fast confirmations, and an interface anyone can master in seconds. Upgrade your UX! ⚡🎯\n\n#DigitalShieldWallet #Web3Wallet #CryptoWallet #Crypto #Web3",
    "Frustrated with slow wallet apps that freeze during peak volatility? Experience lightning-fast Web3 interactions with Digital Shield Wallet APP! 🏎️💨\n\n#DigitalShield #Web3Wallet #CryptoWallet #CryptoSecurity #Web3",
    "Designed for humans, secured by cryptography. Digital Shield delivers a Web3 wallet experience so intuitive you'll never use anything else again! 🛡️🌟\n\n#DigitalShieldWallet #CryptoWallet #Web3Wallet #Crypto #Web3",

    # Category 5: Introduction to Digital Shield APP
    "Meet Digital Shield APP: The revolutionary Web3 wallet built for total asset protection, seamless swaps & effortless crypto control. Download today! 📲🔥\n\n#DigitalShield #DigitalShieldWallet #CryptoWallet #Web3Wallet",
    "New to Digital Shield APP? It's your all-in-one gateway to decentralized finance, ultra-secure private key storage & multi-chain crypto freedom! 🌐🛡️\n\n#DigitalShield #DigitalShieldWallet #Crypto #Web3 #CryptoSecurity",
    "Why millions are switching to Digital Shield APP: Zero custody risk, military encryption, and instant crypto management right from your phone! 📱✨\n\n#DigitalShieldWallet #CryptoWallet #Web3Wallet #CryptoSecurity #Crypto",
    "Welcome to the next evolution of crypto custody. Digital Shield APP is here to redefine how you store, trade, and protect your digital assets! 🚀🛡️\n\n#DigitalShield #DigitalShieldWallet #CryptoWallet #Web3 #Crypto"
]

# ----------------- TOPIC 3: VIRAL X/TWITTER POSTS FOR DSPAY & USDT GATEWAY -----------------
# Categories covered: DSpay payment services, USDT Payment Gateway, Merchant payments, Web3 payments, DSpay features & UX
# Hashtags: #DSpay #USDT #CryptoPayment #Web3Payment #Crypto #Web3 #DigitalPayment
TOPIC3_TEMPLATES = [
    # Category 1: DSpay Payment Services
    "Say goodbye to 3-5 day banking delays. DSpay payment services deliver instant cross-border settlement with ultra-low transaction fees! ⚡🌍\n\n#DSpay #USDT #CryptoPayment #Web3Payment #DigitalPayment",
    "Power your everyday transactions with DSpay. Fast, reliable, and borderless crypto payment services built for the decentralized economy! 💳🚀\n\n#DSpay #USDT #CryptoPayment #Web3Payment #Crypto #Web3",
    "Global payments should be as instant as sending a text. DSpay payment services make sending & receiving USDT seamless worldwide! 📲🌐\n\n#DSpay #USDT #CryptoPayment #DigitalPayment #Web3Payment",
    "Eliminate banking friction forever. DSpay payment services give you the speed, freedom & reliability of on-chain crypto settlements! 💎⚡\n\n#DSpay #CryptoPayment #Web3Payment #DigitalPayment #Crypto #USDT",

    # Category 2: USDT Payment Gateway
    "Accept USDT from customers worldwide with zero volatility risk. The DSpay USDT Payment Gateway settles transactions in under 1 second! ⏱️💰\n\n#DSpay #USDT #CryptoPayment #Web3Payment #DigitalPayment",
    "Tired of losing revenue to card processing fees? DSpay USDT Payment Gateway offers near-zero gas costs and instant direct wallet payouts! 🛡️💸\n\n#DSpay #USDT #CryptoPayment #Web3Payment #Crypto #Web3",
    "Multi-chain USDT payment gateway powered by DSpay. Support for TRC-20 and ERC-20 with automated settlement and zero intermediaries! 🌐⚡\n\n#DSpay #USDT #CryptoPayment #DigitalPayment #Web3Payment",
    "The future of commerce is stablecoins. DSpay USDT Payment Gateway guarantees 1:1 USD pricing with instant on-chain transaction verification! 💵🔒\n\n#DSpay #USDT #CryptoPayment #Web3Payment #DigitalPayment",

    # Category 3: Merchant Payments
    "Merchants: Stop suffering from chargeback fraud! DSpay merchant payments provide 100% irreversible, verified crypto settlements! 🚫🛡️\n\n#DSpay #CryptoPayment #MerchantPayment #Web3Payment #USDT",
    "Boost your e-commerce conversion rates by accepting crypto! DSpay merchant payments plug right into your online checkout in minutes! 🛒📈\n\n#DSpay #USDT #CryptoPayment #Web3Payment #DigitalPayment",
    "From local retail shops to global SaaS platforms, DSpay merchant payments enable fast QR code & web checkouts with zero bank interference! 🏪📲\n\n#DSpay #CryptoPayment #MerchantPayment #Web3Payment #DigitalPayment",
    "Zero setup headaches, zero rolling reserves. DSpay merchant payments give businesses complete financial autonomy with instant USDT payouts! 💼⚡\n\n#DSpay #USDT #CryptoPayment #Web3Payment #DigitalPayment",

    # Category 4: Web3 Payments
    "Web3 payments are transforming how the world transacts. DSpay makes on-chain payments as effortless as swiping a card, but 10x faster! 🌐🚀\n\n#Web3Payment #DSpay #USDT #CryptoPayment #Crypto #Web3",
    "Borderless, permissionless, and ultra-secure. DSpay Web3 payments let you send and receive funds globally with total financial privacy! 🔐💎\n\n#DSpay #Web3Payment #CryptoPayment #USDT #DigitalPayment #Web3",
    "Connect your wallet and pay in seconds. DSpay Web3 payments eliminate paperwork, foreign exchange penalties & intermediary bank fees! ⚡🌍\n\n#DSpay #USDT #Web3Payment #CryptoPayment #DigitalPayment",
    "The bridge between traditional commerce and Web3 is here. DSpay Web3 payments enable high-throughput on-chain settlement for everyone! 🌉🔥\n\n#DSpay #Web3Payment #CryptoPayment #USDT #Crypto #Web3",

    # Category 5: DSpay Product Features & UX
    "One-click API integration, real-time webhook alerts, and an intuitive merchant dashboard. DSpay product features are built for scale! 📊⚙️\n\n#DSpay #CryptoPayment #Web3Payment #DigitalPayment #USDT",
    "Experience next-level payment UX with DSpay. Clean interface, instant payment QR codes, and automated transaction receipts on every checkout! 📲✨\n\n#DSpay #USDT #CryptoPayment #Web3Payment #DigitalPayment",
    "Why developers & businesses love DSpay: Simple SDKs, 99.99% gateway uptime, and automated multi-chain transaction confirmation! 💻🚀\n\n#DSpay #CryptoPayment #Web3Payment #DigitalPayment #Crypto #USDT",
    "Smooth, secure & lightning fast. DSpay's user experience makes paying with USDT as simple as scanning a code. Discover DSpay today! 🛡️⚡\n\n#DSpay #USDT #CryptoPayment #Web3Payment #DigitalPayment"
]

# ----------------- DAILY POST GENERATOR (STABLE DAILY ROTATION) -----------------
def generate_account_posts(account_num, refer_link):
    # Day number changes strictly once per day at 00:00 midnight
    day_number = datetime.now().toordinal()

    # Topic 1: Fixed text with dynamic link
    t1_text = TOPIC1_BASE_TEXT.format(link=refer_link)

    # Topic 2: Daily rotating viral post for Digital Shield Wallet
    t2_idx = (account_num + (day_number * 3)) % len(TOPIC2_TEMPLATES)
    t2_text = TOPIC2_TEMPLATES[t2_idx]

    # Topic 3: Daily rotating viral post for DSpay USDT Gateway
    t3_idx = (account_num + (day_number * 7)) % len(TOPIC3_TEMPLATES)
    t3_text = TOPIC3_TEMPLATES[t3_idx]

    # Topic 3 Graphic: Human-crafted HD banner
    graphic_path = generate_dspay_graphic(account_num)

    return {
        "account": account_num,
        "refer_link": refer_link,
        "topic1": {
            "title": "Topic 1: Work To Earn (Referral System)",
            "text": t1_text
        },
        "topic2": {
            "title": "Topic 2: Digital Shield Wallet APP & Features",
            "text": t2_text
        },
        "topic3": {
            "title": "Topic 3: DSpay Payment Services & USDT Gateway",
            "text": t3_text,
            "graphic_path": graphic_path
        }
    }

# ----------------- KEYBOARDS (ALWAYS INCLUDES COPY POST) -----------------
def build_copy_keyboard(post_text, include_next=False, next_acc=None):
    markup = types.InlineKeyboardMarkup(row_width=1)

    # Prepare copy text ensuring it fits Telegram's 256-character CopyTextButton limit
    copy_val = post_text
    if len(copy_val) > 256:
        # If double newlines make it slightly over 256, condense spacing to keep 100% of text intact
        condensed = post_text.replace("\n\n", "\n")
        if len(condensed) <= 256:
            copy_val = condensed
        else:
            copy_val = copy_val[:256]

    try:
        markup.add(types.InlineKeyboardButton(text="📋 Copy Post", copy_text=types.CopyTextButton(copy_val)))
    except Exception:
        pass

    if include_next and next_acc:
        markup.add(types.InlineKeyboardButton(text=f"Next ➡️ Acc #{next_acc}", callback_data=f"go_acc_{next_acc}"))

    return markup

def get_main_keyboard():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    b1 = types.KeyboardButton("🎯 Generate Posts")
    b2 = types.KeyboardButton("📋 View Saved Links")
    b3 = types.KeyboardButton("🔗 Add / Update Link")
    b4 = types.KeyboardButton("📥 Bulk Import Links")
    b5 = types.KeyboardButton("🗑️ Clear Chat")
    markup.add(b1, b2)
    markup.add(b3, b4)
    markup.add(b5)
    return markup

def get_clear_chat_inline_kb():
    markup = types.InlineKeyboardMarkup(row_width=1)
    b1 = types.InlineKeyboardButton("🗑️ Clear Single Account Chat", callback_data="trx_clear_acc_prompt")
    b2 = types.InlineKeyboardButton("💥 Clear All Chat History", callback_data="trx_clear_all_confirm")
    b3 = types.InlineKeyboardButton("❌ Cancel", callback_data="trx_clear_cancel")
    markup.add(b1, b2, b3)
    return markup

# ----------------- SEND ACCOUNT POSTS -----------------
def send_account_posts(chat_id, acc_num, target_link):
    posts_data = generate_account_posts(acc_num, target_link)

    header_text = (
        f"<b>🚀 ACCOUNT #{acc_num} POSTS READY</b>\n"
        f"Refer Link: <code>{target_link}</code>\n"
        f"<i>Niche 1-by-1 teeno topics ki posts ready hain. <b>'📋 Copy Post'</b> dabate hi exact post copy ho jayegi!</i>"
    )
    send_tracked_message(chat_id, header_text, acc_num=acc_num, parse_mode="HTML")

    # Topic 1
    p1 = posts_data["topic1"]
    msg_t1 = f"<b>📌 {p1['title']}</b>\n\n{p1['text']}"
    kb1 = build_copy_keyboard(p1["text"])
    send_tracked_message(chat_id, msg_t1, acc_num=acc_num, parse_mode="HTML", disable_web_page_preview=True, reply_markup=kb1)

    # Topic 2
    p2 = posts_data["topic2"]
    msg_t2 = f"<b>📌 {p2['title']}</b>\n\n{p2['text']}"
    kb2 = build_copy_keyboard(p2["text"])
    send_tracked_message(chat_id, msg_t2, acc_num=acc_num, parse_mode="HTML", disable_web_page_preview=True, reply_markup=kb2)

    # Topic 3 + Photo
    p3 = posts_data["topic3"]
    caption = f"<b>📌 {p3['title']}</b>\n\n{p3['text']}"
    next_acc = (acc_num + 1) if acc_num < 100 else 1
    kb3 = build_copy_keyboard(p3["text"], include_next=True, next_acc=next_acc)

    with open(p3["graphic_path"], "rb") as photo:
        send_tracked_photo(chat_id, photo, acc_num=acc_num, caption=caption, parse_mode="HTML", reply_markup=kb3)

# ----------------- HANDLERS -----------------
@bot.message_handler(commands=["start", "help"])
def send_welcome(message):
    welcome_text = (
        "<b>🛡️ Welcome to Digital Shield Post Generator Bot</b>\n\n"
        "Ye bot 100 accounts ke liye 3 topics ki <b>Daily Fresh & Viral</b> posts provide karta hai:\n"
        "• <b>Topic 1:</b> Work To Earn (Fixed Text + Dynamic Refer Link)\n"
        "• <b>Topic 2:</b> Digital Shield Wallet APP & Features (Daily Rotating Viral Post)\n"
        "• <b>Topic 3:</b> DSpay Payment Services & USDT Gateway + <b>Topic-Related Custom 1080x1080 HD Graphic Banner</b>\n\n"
        "<b>✨ Features:</b>\n"
        "✅ <b>Daily New Post:</b> Har din automatically naya post (pure din consistent rahega)\n"
        "✅ <b>Har Account ka Unique DSpay Graphic:</b> Har account ke liye fresh style crypto banner\n"
        "✅ <b>Clipboard Copy:</b> Har post ke niche '📋 Copy Post' button\n"
        "✅ <b>🗑️ Clear Chat Button:</b> Single account ya All Chat 1-click me clean karein!\n"
        "✅ <b>Permanent Database:</b> Links hamesha saved rahenge\n\n"
        "Niche diye gaye buttons se shuru karein 👇"
    )
    send_tracked_message(message.chat.id, welcome_text, parse_mode="HTML", reply_markup=get_main_keyboard())

@bot.message_handler(func=lambda msg: msg.text in ["🎯 Generate Posts", "Generate Posts", "dYs? Generate Posts"])
def handle_generate_posts_btn(message):
    user_states[message.chat.id] = "waiting_acc_num"
    send_tracked_message(
        message.chat.id,
        "<b>Account Number bhejo (1 se 100):</b>\nExample: <code>1</code> ya <code>5</code>",
        parse_mode="HTML"
    )

@bot.message_handler(func=lambda msg: msg.text in ["📋 View Saved Links", "View Saved Links", "dY\"< View Saved Links"])
def handle_view_links_btn(message):
    links = load_permanent_links()
    if not links:
        send_tracked_message(
            message.chat.id,
            "❌ Abhi koi link save nahi hai.\n'🔗 Add / Update Link' se link add karein.",
            reply_markup=get_main_keyboard()
        )
        return

    text = f"<b>📋 PERMANENT SAVED LINKS ({len(links)}/100 Saved)</b>\n\n"
    sorted_accs = sorted([int(k) for k in links.keys() if k.isdigit()])
    for acc in sorted_accs[:30]:
        text += f"• <b>Acc #{acc}:</b> <code>{links[str(acc)]}</code>\n"
    if len(sorted_accs) > 30:
        text += f"\n<i>...aur {len(sorted_accs) - 30} links saved hain.</i>"

    send_tracked_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_main_keyboard())

@bot.message_handler(func=lambda msg: msg.text in ["🔗 Add / Update Link", "Add / Update Link", "z  Add / Update Link"])
def handle_add_link_btn(message):
    user_states[message.chat.id] = "waiting_single_link"
    send_tracked_message(
        message.chat.id,
        "<b>Link Save karne ka format:</b>\n\n<code>[Account Number] [Refer Link]</code>\n\n<b>Example:</b>\n<code>1 https://worktoearnoecm.icanfly.cyou/#/?invite=CFE6E2</code>",
        parse_mode="HTML"
    )

@bot.message_handler(func=lambda msg: msg.text in ["📥 Bulk Import Links", "Bulk Import Links", "dY\" Bulk Import Links"])
def handle_bulk_import_btn(message):
    user_states[message.chat.id] = "waiting_bulk_links"
    send_tracked_message(
        message.chat.id,
        "<b>📥 BULK IMPORT LINKS</b>\n\nSaare 100 accounts ke links ek saath paste kar sakte ho:\n\n<b>Format:</b>\n<code>1 https://link1\n2 https://link2</code>\n\nYa seedha links line-by-line paste kar do.",
        parse_mode="HTML"
    )

@bot.message_handler(func=lambda msg: msg.text in ["🗑️ Clear Chat", "Clear Chat", "dY 1 Clear Chat", "/clear"])
def handle_clear_chat_btn(message):
    text = (
        "<b>🗑️ CHAT CLEAR MENU</b>\n\n"
        "Daily kaam complete hone ke baad chat ko clean karein:\n\n"
        "• <b>Clear Single Account Chat:</b> Kisi ek account (e.g. Account #1) ke saare posts & graphics delete karein.\n"
        "• <b>Clear All Chat History:</b> Aaj ke saare daily messages & posts 1-click me clean karein."
    )
    send_tracked_message(message.chat.id, text, parse_mode="HTML", reply_markup=get_clear_chat_inline_kb())

# ----------------- TEXT FLOW -----------------
@bot.message_handler(func=lambda msg: True)
def handle_all_text(message):
    chat_id = message.chat.id
    state = user_states.get(chat_id)
    text = message.text.strip()

    # State: Clear Single Account
    if state == "waiting_clear_acc_num":
        user_states.pop(chat_id, None)
        if not text.isdigit():
            send_tracked_message(chat_id, "⚠️ Invalid Account Number. Kripya sirf number bhejo (e.g. <code>1</code>).", parse_mode="HTML")
            return
        target_acc = text
        tracker = load_tracker()
        cid = str(chat_id)
        acc_msgs = tracker.get(cid, {}).get("by_acc", {}).get(target_acc, [])
        if not acc_msgs:
            send_tracked_message(chat_id, f"ℹ️ Account #{target_acc} ke liye chat me koi tracked messages nahi mile.", reply_markup=get_main_keyboard())
            return

        status_msg = bot.send_message(chat_id, f"🗑️ Account #{target_acc} ke messages delete ho rahe hain...")
        deleted = delete_messages(chat_id, acc_msgs)
        tracker[cid]["by_acc"][target_acc] = []
        tracker[cid]["all"] = [m for m in tracker[cid]["all"] if m not in acc_msgs]
        save_tracker(tracker)
        try:
            bot.delete_message(chat_id, status_msg.message_id)
        except Exception:
            pass
        send_tracked_message(chat_id, f"✅ <b>Account #{target_acc}</b> ke {deleted} posts & graphics chat se successfully clear kar diye gaye! 🗑️", parse_mode="HTML", reply_markup=get_main_keyboard())
        return

    # State: Waiting Single Link
    if state == "waiting_single_link":
        parts = text.split()
        if len(parts) >= 2 and parts[0].isdigit():
            acc_num = parts[0]
            link = parts[1]
            links = load_permanent_links()
            links[acc_num] = link
            save_permanent_links(links)
            user_states.pop(chat_id, None)
            send_tracked_message(
                chat_id,
                f"✅ <b>Account #{acc_num} ka link permanently save ho gaya!</b>\n\nLink: <code>{link}</code>\n\nAb jab bhi posts chahiye, bas <code>{acc_num}</code> bhejo!",
                parse_mode="HTML",
                reply_markup=get_main_keyboard()
            )
            return
        elif text.startswith("http://") or text.startswith("https://"):
            links = load_permanent_links()
            next_free = 1
            while str(next_free) in links:
                next_free += 1
            links[str(next_free)] = text
            save_permanent_links(links)
            user_states.pop(chat_id, None)
            send_tracked_message(
                chat_id,
                f"✅ Link auto-assigned to <b>Account #{next_free}</b> and saved!\nLink: <code>{text}</code>",
                parse_mode="HTML",
                reply_markup=get_main_keyboard()
            )
            return
        else:
            send_tracked_message(
                chat_id,
                "⚠️ Format sahi nahi hai. Aise bhejo:\n<code>1 https://apna_refer_link</code>",
                parse_mode="HTML"
            )
            return

    # State: Waiting Bulk Links
    if state == "waiting_bulk_links":
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        if not lines:
            send_tracked_message(chat_id, "Koi links nahi mile.")
            return
        links = load_permanent_links()
        imported_count = 0
        for idx, line in enumerate(lines, 1):
            parts = line.split()
            if len(parts) >= 2 and parts[0].isdigit():
                acc = parts[0]
                lnk = parts[1]
            elif line.startswith("http://") or line.startswith("https://"):
                acc = str(idx)
                lnk = line
            else:
                continue
            links[acc] = lnk
            imported_count += 1
        save_permanent_links(links)
        user_states.pop(chat_id, None)
        send_tracked_message(
            chat_id,
            f"🎉 <b>Success! {imported_count} links permanently save ho gaye!</b>\n\nTotal saved links in DB: <b>{len(links)}/100</b>\nAb kisi bhi account ki posts ke liye bas uska number bhejo (e.g. <code>1</code>).",
            parse_mode="HTML",
            reply_markup=get_main_keyboard()
        )
        return

    # State: Waiting Acc Num (or direct number sent)
    if text.isdigit() or state == "waiting_acc_num":
        if not text.isdigit():
            bot.reply_to(message, "Kripya valid number bhejo (1 se 100 tak).")
            return
        acc_num = int(text)
        if acc_num < 1 or acc_num > 100:
            bot.reply_to(message, "⚠️ Account number 1 se 100 ke beech hona chahiye.")
            return

        links = load_permanent_links()
        target_link = links.get(str(acc_num), "")
        if not target_link:
            user_states[chat_id] = "waiting_single_link"
            send_tracked_message(
                chat_id,
                f"⚠️ <b>Account #{acc_num} ka Refer Link Database me nahi mila!</b>\n\n"
                f"Pehle is account ka link bhejo taaki ye database me save ho sake:\n"
                f"Format: <code>{acc_num} https://apna_refer_link</code>\n\n"
                f"<i>(Ek baar bhej doge toh hamesha ke liye save ho jayega)</i>",
                parse_mode="HTML"
            )
            return

        user_states.pop(chat_id, None)
        send_account_posts(chat_id, acc_num, target_link)
        return

    # Default fallback
    bot.reply_to(
        message,
        "Kisi bhi account ki posts ke liye bas uska <b>Account Number</b> bhejo (e.g. <code>1</code>, <code>2</code>).\nYa niche buttons use karo 👇",
        parse_mode="HTML",
        reply_markup=get_main_keyboard()
    )

# ----------------- CALLBACK QUERY HANDLER -----------------
@bot.callback_query_handler(func=lambda call: True)
def handle_callback(call):
    data = call.data
    chat_id = call.message.chat.id

    # Next Account navigation
    if data.startswith("go_acc_"):
        acc_num = int(data.split("_")[-1])
        bot.answer_callback_query(call.id)
        links = load_permanent_links()
        target_link = links.get(str(acc_num), "")
        if not target_link:
            send_tracked_message(
                chat_id,
                f"⚠️ <b>Account #{acc_num} ka Refer Link Database me nahi mila!</b>\n\nAise bhejo:\n<code>{acc_num} https://apna_refer_link</code>",
                parse_mode="HTML"
            )
            return
        send_account_posts(chat_id, acc_num, target_link)
        return

    # Clear Chat: Single Account Prompt
    if data == "trx_clear_acc_prompt":
        bot.answer_callback_query(call.id)
        user_states[chat_id] = "waiting_clear_acc_num"
        send_tracked_message(
            chat_id,
            "<b>Kis Account ki posts chat se clear karni hai?</b>\nAccount number bhejo (1 se 100):\nExample: <code>1</code> ya <code>12</code>",
            parse_mode="HTML"
        )
        return

    # Clear Chat: All Confirm
    if data == "trx_clear_all_confirm":
        bot.answer_callback_query(call.id)
        markup = types.InlineKeyboardMarkup(row_width=2)
        b_yes = types.InlineKeyboardButton("✅ Haan, Clear All Messages", callback_data="trx_clear_all_execute")
        b_no = types.InlineKeyboardButton("❌ Cancel", callback_data="trx_clear_cancel")
        markup.add(b_yes, b_no)
        send_tracked_message(
            chat_id,
            "⚠️ <b>CONFIRM: DAILY CHAT CLEAR</b>\n\nKya aap sach me aaj ke saare daily posts aur bot messages chat se delete karna chahte hain?",
            parse_mode="HTML",
            reply_markup=markup
        )
        return

    # Clear Chat: All Execute
    if data == "trx_clear_all_execute":
        bot.answer_callback_query(call.id, text="Saari chat clear ho rahi hai... 🗑️")
        tracker = load_tracker()
        cid = str(chat_id)
        all_msgs = tracker.get(cid, {}).get("all", [])

        status_msg = bot.send_message(chat_id, "🗑️ Daily chat history delete ho rahi hai...")
        deleted = delete_messages(chat_id, all_msgs)
        tracker[cid] = {"all": [], "by_acc": {}}
        save_tracker(tracker)
        try:
            bot.delete_message(chat_id, status_msg.message_id)
        except Exception:
            pass
        send_tracked_message(
            chat_id,
            f"✅ <b>Daily chat clean complete!</b>\nTotal {deleted} messages & graphics delete kar diye gaye.\n\nAgle din ka kaam shuru karne ke liye niche buttons use karein 👇",
            parse_mode="HTML",
            reply_markup=get_main_keyboard()
        )
        return

    # Clear Chat: Cancel
    if data == "trx_clear_cancel":
        bot.answer_callback_query(call.id, text="Cancelled")
        try:
            bot.delete_message(chat_id, call.message.message_id)
        except Exception:
            pass
        return

if __name__ == "__main__":
    print("=" * 60)
    print(">> Enhanced Dailytrx Bot (@Dailytrxmatebot) is RUNNING!")
    print(f">> Token: {TOKEN}")
    print("=" * 60)
    bot.infinity_polling(none_stop=True, timeout=60)
