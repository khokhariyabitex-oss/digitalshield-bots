# Digital Shield Telegram Bots (24/7 Render Deployment)

Yeh repository dono Telegram Bots ko Render pe 24/7 run karne ke liye tayar ki gayi hai:
- **Bot 1:** Dailytrx Post Bot ([@Dailytrxmatebot](https://t.me/Dailytrxmatebot))
- **Bot 2:** Proof Manager Bot ([@Mangerprofbot](https://t.me/Mangerprofbot))

---

## 🚀 Render Pe Deploy Karne Ke Steps (Step-by-Step):

### Step 1: GitHub Pe Repository Banayein
1. [GitHub](https://github.com/) pe login karein aur **New Repository** banayein (naam jaise: `digitalshield-bots`).
2. Public ya Private koi bhi select karein.
3. Is folder ki files upload karein:
   - `combined_runner.py`
   - `friend_trx_bot.py`
   - `friend_manager_bot.py`
   - `requirements.txt`
   - `render.yaml`
   - `Procfile`
   - `.gitignore`
   - Folders: `data_trx/` aur `data_manager/`
   *(Dhyan dein: `python_env` aur `packages_runtime` upload nahi karna hai, wo Render ke liye zaroori nahi hain!)*

---

### Step 2: Render.com Pe Web Service Banayein
1. [Render.com](https://dashboard.render.com/) pe login karein.
2. **New +** button pe click karke **Web Service** choose karein.
3. Apni GitHub repository ko connect karein.
4. Settings check karein:
   - **Name:** `digitalshield-telegram-bots`
   - **Runtime:** `Python 3`
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python combined_runner.py`
   - **Instance Type:** `Free`
5. **Deploy Web Service** pe click karein!

---

### Step 3: Bots 24/7 Bina Soe Chalte Rahe (Keep-Alive Free Setup)
Render ka free tier 15 minutes inactive rehne par so (sleep mode me) jata hai.
Lekin humne isme ek built-in Web Server laga diya hai!

1. Jab Render pe deploy complete ho jaye, to aapko ek URL milega (jaise `https://digitalshield-telegram-bots.onrender.com`).
2. Free keep-alive site jaise [cron-job.org](https://cron-job.org/) ya [uptimerobot.com](https://uptimerobot.com/) pe jayein.
3. Ek free monitor / cron job banayein jo har **5 se 10 minutes** me is URL ko ping kare:
   - URL: `https://apka-service-naam.onrender.com/`
4. Isse Render service hamesha "Active" rahegi aur dono bots **24 ghante 365 din** bina ruke chalenge!
